=== Doolox Plugin ===
Contributors: tpiha
Tags: wordpress, doolox, wordpress manager, remote login
Donate link: https://www.doolox.com
Requires at least: 3.7
Tested up to: 3.7
Stable tag: trunk
License: GPL
License URI: https://github.com/tpiha/doolox-plugin/blob/master/LICENSE

Doolox Plugin is a WordPress plugin for Doolox, free Open Source WordPress management tool and website builder.

== Description ==
Doolox is a free Open Source WordPress management tool and website builder available both as a SaaS and for download. It uses Doolox Plugin to login users to multiple WordPress websites over SSL without storing credentials in database. Give it a try, it\'s free!

== Installation ==
1. Upload the plugin folder to your /wp-content/plugins/ folder
2. Go to the Plugins page and activate Doolox Plugin
3. Visit [doolox.com](https://www.doolox.com/) and connect your WordPress website

== Screenshots ==
1. Doolox Dashboard

== Changelog ==
### v1.1 (Jan 20 2014) ###

* Implemented SSL

### v1.0 (Jan 20 2014) ###

* Finished first version

== Frequently Asked Questions ==
No FAQs at the moment.

== Upgrade notice ==
No upgrade notices at the moment.