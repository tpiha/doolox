Dear Doolox user,<br />
<br />
Welcome to Doolox!<br />
<br />
In order to proceed, please click on the link below and activate your Doolox account:<br />
<br />
<a href={{ route('user.activate', array('user_id' => $user->id, 'code' => $code )) }}>Activate Accout</a><br />
<br />
Best regards,<br />
your Doolox team