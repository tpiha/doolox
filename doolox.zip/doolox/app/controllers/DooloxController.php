<?php

class DooloxController extends BaseController {

	public function dashboard()
    {
        $rsa = new Crypt_RSA();
        $rsa->loadKey(Config::get('doolox.private_key'));
        $user = Sentry::getUser();
        $sites = $user->getSites()->get();
        foreach ($sites as $site) {
            $link = $site->url;
            $link = str_replace('http://', '', $link);
            $link = str_replace('https://', '', $link);
            if (substr($link, -1) == '/') {
                $link = substr($link, 0, -1);
            }
            $site->link = $link;
        }
		return View::make('dashboard')->with('sites', $sites);
	}

    public function site($id)
    {
        $validator = null;
        $site = Site::findOrFail((int) $id);

        if (Request::has('name')) {
            $rules = array(
                'name' => 'required',
                'url' => 'required',
            );
            $validator = Validator::make(Input::all(), $rules);
            if ($validator->passes()) {
                $site->fill(Input::except('_token'));
                $site->save();
                Session::flash('success', 'Website successfully updated.');
                return Redirect::route('doolox.dashboard');
            }
        }

        return View::make('site')->with('site', $site)->withErrors($validator);
    }

    public function site_new()
    {
        Validator::extend('wpurl', function($attribute, $value, $parameters)
        {
            if (strpos($value, 'http://') !== 0 && strpos($value, 'https://') !== 0) {
                $value = 'http://' . $value;
            }
            if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/", $value)) {
                return false;
            }
            else {
                return true;
            }
        });

        $messages = array(
            'wpurl' => 'URL is not valid. Allowed characters are lowercase alphanumeric, dash, dot and slash. URL can start with http:// or https://.',
        );

        $rules = array(
            'name' => 'required',
            'url' => 'required|wpurl',
            'username' => 'required_if:doolox_node,true',
            'password' => 'required_if:doolox_node,true',
        );

        $validator = Validator::make(Input::all(), $rules, $messages);

        if ($validator->passes()) {
            $input = Input::except(array('_token', 'username', 'password', 'doolox_node'));
            if (strpos($input['url'], 'http://') !== 0 && strpos($input['url'], 'https://') !== 0) {
                $input['url'] = 'http://' . $input['url'];
            }
            if (substr($input['url'], -1) != '/') {
                $input['url'] .= '/';
            }
            if (strlen($input['admin_url']) && $input['admin_url'][0] == '/') {
                 $input['admin_url'] = substr($input['admin_url'], 1);
            }
            $site = Site::create($input);
            $user = Sentry::getUser();
            $user->getSites()->attach($site);

            if (Input::get('doolox_node')) {
                self::install_doolox_node($input['url'], Input::get('username'), Input::get('password'));
            }

            Session::flash('success', 'New website successfully added.');
            return Redirect::route('doolox.dashboard');
        }

        Input::flash();

        return View::make('site_new')->withErrors($validator);
    }

    public function site_delete($id)
    {
        $site = Site::findOrFail((int) $id);
        $wpusersites = SiteUser::where('site_id', (int) $id)->get();
        foreach ($wpusersites as $wpusersite) {
            // die(var_dump($wpusersite->user_id));
            $wpusersite->delete();
        }
        $site->delete();
        Session::flash('success', 'Website successfully deleted.');
        return Redirect::route('doolox.dashboard');
    }

    public function site_rmuser($id, $user_id)
    {
        $site = Site::find($id);
        $site->getUsers()->detach($user_id);
        $site->save();
        Session::flash('success', 'User successfully removed from the website.');
        return Redirect::route('doolox.dashboard');
    }

    public function site_adduser($id)
    {
        if (Input::get('email')) {
            $user = User::where('email', Input::get('email'))->first();
            if ($user) {
                $user->getSites()->attach((int) $id);
                $user->save();
                Session::flash('success', 'User successfully added to the website.');
                return Redirect::route('doolox.dashboard');
            }
            else {
                Session::flash('error', 'There is no user with this email.');
                return Redirect::route('doolox.site', array('id' => $id));
            }
        }
        else {
            Session::flash('error', 'Email field is required.');
            return Redirect::route('doolox.site', array('id' => $id));
        }
    }

    public function site_install()
    {
        $domains = array();
        $_domains = Sentry::getUser()->getDomains()->get();
        $selected = 0;
        $selected_url = '';
        foreach ($_domains as $domain) {
            $domains["$domain->url"] = $domain->url;
            $selected_url = $domain->url;
        }
        // dd($domains);
        return View::make('site_install')->with(array('domains' => $domains, 'selected_url' => $selected_url));
    }

    public function site_install_post()
    {
        $domains = Sentry::getUser()->getDomains()->get();

        Validator::extend('domainav', function($attribute, $value, $parameters)
        {
            $domain = explode('.', $value);
            $subdomain = $domain[0];
            $domain = $domain[1] . '.' . $domain[2];
            $d = Domain::where('url', $domain)->first();
            if (Site::where('domain_id', $d->id)->where('subdomain', $subdomain)->count()) {
                return false;
            }
            else {
                return true;
            }
        });

        Validator::extend('wpurl', function($attribute, $value, $parameters)
        {
            if ($value == strtolower($value)) {
                return true;
            }
            else {
                return false;
            }
        });

        $messages = array(
            'domainav' => 'This domain is not available.',
            'wpurl' => 'URL is not valid. Allowed characters are lowercase alphanumeric, dash, and dot.',
        );

        $rules = array(
            'url' => 'required|domainav|wpurl',
        );
        $validator = Validator::make(Input::all(), $rules, $messages);
        if ($validator->passes()) {
            return Redirect::route('doolox.site_install_step2')->with(array('domain' => Input::get('domain'), 'url' => Input::get('url')));
        }
        $_domains = array();
        foreach ($domains as $domain) {
            $_domains["$domain->url"] = $domain->url;
            $selected_url = $domain->url;
        }

        Input::flash();

        return View::make('site_install')->withErrors($validator)->with(array('domains' => $_domains, 'selected_url' => $selected_url));
    }

    public function site_install_step2()
    {
        $domain = Input::get('domain');
        $url = Input::get('url');
        $url = str_replace('http://', '', $url);
        $url = str_replace('https://', '', $url);

        $rules = array(
            'url' => 'required|not_in:' . Config::get('doolox.system_domain') . ',',
            'title' => 'required',
            'username' => 'required',
            'email' => 'required|email',
            'password1' => 'required|same:password2',
            'password2' => 'required|same:password1',
        );

        $validator = Validator::make(Input::all(), $rules);

        if ($validator->passes()) {
            $title = Input::get('title');
            $username = Input::get('username');
            $password = Input::get('password1');
            $email = Input::get('email');

            $subdomain = str_replace('.' . $domain, '', $url);
            $d = Domain::where('url', $domain)->first();

            $user = Sentry::getUser();
            $site = Site::create(array('user_id' => $user->id, 'name' => $title, 'url' => 'http://' . $url . '/', 'local' => true, 'admin_url' => '', 'domain_id' => $d->id, 'subdomain' => $subdomain));
            $user->getSites()->attach($site);

            self::get_wordpress(Sentry::getUser(), $url);
            $dbname = 'doolox' . $user->id . '_db' . $site->id;
            $dbpass = str_random(32);
            self::create_database($dbname, $dbname, $dbpass);
            self::create_wp_config($user, $url, $dbname, $dbpass);
            try {
                self::install_wordpress($url, $title, $username, $password, $email);
            }
            catch (Exception $e) {}
            self::install_doolox_node('http://' . $url . '/', $username, $password);
            Session::flash('success', 'New Doolox website successfully installed.');
            return Redirect::route('doolox.dashboard');
        }

        Input::flash();

        return View::make('site_install_step2')->with(array('domain' => $domain, 'url' => $url))->withErrors($validator);
    }

    public function check_subdomain($domain)
    {
        // $taken = array('blog', 'wiki', 'admin', '');
        if ($domain != '.' . Config::get('doolox.system_domain')) {
            $domain = explode('.', $domain);
            $subdomain = $domain[0];
            $domain = $domain[1] . '.' . $domain[2];
            $d = Domain::where('url', $domain)->first();
            if (Site::where('domain_id', $d->id)->where('subdomain', $subdomain)->count()) {
                return Response::json(array('free' => false, 'status' => 3));
            }
            else {
                return Response::json(array('free' => true, 'status' => 0));
            }
        }
        else {
            return Response::json(array('free' => false, 'status' => 1));
        }
    }

    public function check_domain($domain)
    {
        $da = DooloxController::is_domain_available($domain, Sentry::getUser());
        return Response::json(array('free' => $da[0], 'status' => $da[1]));
    }

    public static function is_domain_available($domain, $user)
    {
        $domain = explode('.', $domain);
        try {
            $subdomain = $domain[2];
            $tld = $subdomain;
            $subdomain = $domain[0];
            $domain = $domain[1];
        }
        catch (Exception $e) {
            $subdomain = '';
            try {
                $tld = $domain[1];
                $domain = $domain[0];
            }
            catch (Exception $e) {
                // no dots
                return array(false, 1);
            }
        }

        // check allowed characters
        if ($tld == Str::slug($tld) && $domain == Str::slug($domain) && $subdomain == Str::slug($subdomain)) {

            $domain = join(array($domain, $tld), '.');

            if ($domain != Config::get('doolox.system_domain')) {
                if (Domain::where('url', $domain)->count()) {
                    return array(false, 3);
                }
                else if (in_array($tld, array('com', 'net', 'org'))) {
                    if (self::namecom_is_available($domain)) {
                        Log::debug("Name.com - domain available: $domain");
                        return array(true, 0);
                    }
                    else {
                        return array(false, 2);
                    }
                }
                else {
                    $ip = gethostbyname($domain);
                    if ($ip == $domain) {
                        return array(false, 2);
                    }
                    else {
                        return array(true, 0);
                    }
                }                    
            }
            else {
                return array(false, 3);
            }
        }
        else {
            return array(false, 1);
        }
    }

    public static function namecom_is_available($domain)
    {
        require_once(base_path() . "/tools/namecom_api.php");
        $api = new NameComApi();
        $api->baseUrl(Config::get('doolox.namecom_url'));
        $api->username(Config::get('doolox.namecom_user'));
        $api->apiToken(Config::get('doolox.namecom_token'));
        $response = $api->check_domain($domain);
        return $response->domains->{$domain}->avail;
    }

    public static function create_database($database, $username, $password)
    {
        DB::connection('managemysql')->statement("CREATE DATABASE $database");
        DB::connection('managemysql')->statement("GRANT ALL ON $database.* TO '$username'@'localhost' IDENTIFIED BY '$password'");
        DB::connection('managemysql')->statement("FLUSH PRIVILEGES");
    }

    public static function drop_database($dbname)
    {
        DB::connection('managemysql')->statement("DROP USER $dbname@localhost");
        DB::connection('managemysql')->statement("DROP DATABASE $dbname");
        DB::connection('managemysql')->statement("FLUSH PRIVILEGES");
    }

    public static function install_wordpress ($url, $title, $username, $password, $email)
    {
        $data = array(
            'weblog_title' => $title,
            'user_name' => $username,
            'admin_password' => $password,
            'admin_password2' => $password,
            'admin_email' => $email,
            'blog_public' => 1,
        );
        $response = Requests::post('http://' . $url . '/wp-admin/install.php?step=2', array('timeout' => 90), $data);
    }

    public static function get_wordpress($user, $domain)
    {
        $source = base_path() . '/wordpress';
        $dest = base_path() . '/users/' . $user->email . '/' . $domain;

        mkdir($dest);

        foreach (
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($source, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::SELF_FIRST) as $item
            ) {
            if ($item->isDir()) {
                mkdir($dest . DIRECTORY_SEPARATOR . $iterator->getSubPathName());
            } else {
                copy($item, $dest . DIRECTORY_SEPARATOR . $iterator->getSubPathName());
            }
        }

        symlink($dest, base_path() . '/websites/' . $domain);
    }

    public static function create_wp_config($user, $domain, $dbname, $dbpass)
    {
        $source = base_path() . '/tools/wp-config.php';
        $dest = base_path() . '/users/' . $user->email . '/' . $domain . '/wp-config.php';
        $wpconfig = file_get_contents($source);

        $wpconfig = str_replace('###DB_NAME###', $dbname, $wpconfig);
        $wpconfig = str_replace('###DB_USER###', $dbname, $wpconfig);
        $wpconfig = str_replace('###DB_PASSWORD###', $dbpass, $wpconfig);
        $wpconfig = str_replace('###DB_HOST###', 'localhost', $wpconfig);

        $wpconfig = str_replace('###AUTH_KEY###', str_random(32), $wpconfig);
        $wpconfig = str_replace('###SECURE_AUTH_KEY###', str_random(32), $wpconfig);
        $wpconfig = str_replace('###LOGGED_IN_KEY###', str_random(32), $wpconfig);
        $wpconfig = str_replace('###LOGGED_IN_KEY###', str_random(32), $wpconfig);
        $wpconfig = str_replace('###AUTH_SALT###', str_random(32), $wpconfig);
        $wpconfig = str_replace('###SECURE_AUTH_SALT###', str_random(32), $wpconfig);
        $wpconfig = str_replace('###LOGGED_IN_SALT###', str_random(32), $wpconfig);
        $wpconfig = str_replace('###NONCE_SALT###', str_random(32), $wpconfig);

        file_put_contents($dest, $wpconfig);
    }

    public static function install_doolox_node($url, $username, $password)
    {
        Log::debug($url . ' ' . $username . ' ' . $password);
        $headers = array();
        $options = array();

        $session = new Requests_Session($url);

        $data = array('log' => $username, 'pwd' => $password);
        $request = $session->post('wp-login.php', array(), $data);

        $request = $session->get('wp-admin/plugin-install.php?tab=search&s=doolox+node&plugin-search-input=Search+Plugins', $headers, $options);

        $start = strpos($request->body, 'update.php?action=install-plugin&amp;plugin=doolox-node');
        Log::debug($start);
        $end = strpos($request->body, '"', $start);
        Log::debug($end);
        $length = $end - $start;

        $link = substr($request->body, $start, $length);
        $link = str_replace($url, '', $link);
        $link = str_replace('&amp;', '&', $link);

        Log::debug($link);

        try {
            $request = $session->get('wp-admin/' . $link, $headers, $options);
        }
        catch (Exception $e) {
            // Plugin already installed
            return false;
        }

        $start = strpos($request->body, 'plugins.php?action=activate&amp;plugin=doolox-node%2Fdoolox.php');
        $end = strpos($request->body, '"', $start);
        $length = $end - $start;

        $link = substr($request->body, $start, $length);
        $link = str_replace($url, '', $link);
        $link = str_replace('&amp;', '&', $link);

        Log::debug($link);

        $request = $session->get('wp-admin/' . $link, $headers, $options);

        return true;
    }

    public function wpcipher_connect($id, $username) {
        $site = Site::find($id);
        $rsa = new Crypt_RSA();

        if ($site->private_key) {
            $privatekey = $site->private_key;
            $publickey = $site->public_key;
        }
        else {
            extract($rsa->createKey());
            $site->private_key = $privatekey;
            $site->public_key = $publickey;
            $site->save();
        }

        $rsa->loadKey(Config::get('doolox.private_key'));

        $data = array(
            'id' => $site->id,
            'action' => 'connect',
            'username' => $username,
            'public_key' => $publickey,
            'rand' => str_random(32),
            'url' => Config::get('app.url')
        );

        $data = json_encode($data);
        $data = base64_encode($data);
        $data = $rsa->encrypt($data);
        $data = base64_encode($data);
        $data = urlencode($data);

        return Response::json(array('cipher' => $data));
    }

    public function wpcipher_login($id) {
        $site = Site::find($id);

        $rsa = new Crypt_RSA();
        $rsa->loadKey($site->private_key);

        $data = array(
            'id' => (string) $site->id,
            'action' => 'login',
            'rand' => str_random(32),
        );

        $data = json_encode($data);
        $data = base64_encode($data);
        $data = $rsa->encrypt($data);
        $data = base64_encode($data);
        $data = urlencode($data);

        return Response::json(array('cipher' => $data));
    }

    public function connected() {
        $site_id = Input::get('id');
        $site = Site::find($site_id);
        $site->connected = true;
        $site->save();
    }

    public function site_move($id)
    {
        $site = Site::find($id);
        if ($site->local) {
            $domains = array();
            $_domains = Sentry::getUser()->getDomains()->get();
            $selected = 0;
            $selected_url = '';
            foreach ($_domains as $domain) {
                $domains["$domain->url"] = $domain->url;
                $selected_url = $domain->url;
            }
            return View::make('site_move')->with(array('domains' => $domains, 'selected_url' => $selected_url, 'site' => $site));
        }
        else {
            Session::flash('error', 'Remote websites can\'t be migrated.');
            return Redirect::route('doolox.dashboard');
        }
    }

    public function site_move_post($id)
    {
        $domains = Sentry::getUser()->getDomains()->get();
        $site = Site::find($id);
        Validator::extend('domainav', function($attribute, $value, $parameters)
        {
            $domain = explode('.', $value);
            $subdomain = $domain[0];
            $domain = $domain[1] . '.' . $domain[2];

            $d = Domain::where('url', $domain)->first();
            if (Site::where('domain_id', $d->id)->where('subdomain', $subdomain)->count()) {
                return false;
            }
            else if (!strlen($subdomain)) {
                return false;
            }
            else {
                return true;
            }
        });

        $messages = array(
            'domainav' => 'This domain is not available.',
        );

        $rules = array(
            'url' => 'required|domainav',
        );

        $validator = Validator::make(Input::all(), $rules, $messages);

        if ($validator->passes()) {
            $site->change_domain(Input::get('url'));
            Session::flash('success', 'Website successfully moved.');
            return Redirect::route('doolox.dashboard');
        }

        $_domains = array();
        foreach ($domains as $domain) {
            $_domains["$domain->url"] = $domain->url;
            $selected_url = $domain->url;
        }

        Input::flash();

        return View::make('site_move')->withErrors($validator)->with(array('domains' => $_domains, 'selected_url' => $selected_url, 'site' => $site));
    }

    public static function folder_size($dir){
        $count_size = 0;
        $count = 0;
        $dir_array = scandir($dir);
        foreach($dir_array as $key=>$filename) {
            if($filename!=".." && $filename!=".") {
                if(is_dir($dir."/".$filename)) {
                    $new_foldersize = self::folder_size($dir."/".$filename);
                    $count_size = $count_size + $new_foldersize;
                } else if(is_file($dir."/".$filename)) {
                    $count_size = $count_size + filesize($dir."/".$filename);
                    $count++;
                }
            }

        }
        return $count_size;
    }

    public function upgrade()
    {
        return View::make('upgrade');
    }

    public function paid_plan() {
        $privatekey = Config::get('doolox.fskey');
        $secdata = $_REQUEST['security_data'];
        $sechash = $_REQUEST['security_hash'];

        if (md5($secdata . $privatekey) == $sechash) {
            $product = Input::get('SubscriptionPath');
            $user_id = (int) Input::get('SubscriptionReferrer');

            if ($product == '/pro1month') {
                $group = Sentry::findGroupByName('Doolox Pro');
            }
            else if ($product == '/business1month') {
                $group = Sentry::findGroupByName('Doolox Business');
            }
            else {
                $group = Sentry::findGroupByName('Doolox Unlimited');
            }
            $user = Sentry::findUserById($user_id);
            $user->addGroup($group);

            Log::info('FastSpring - user activated: ' . $user->email);
        }
    }

    public function paid_domain() {
        require_once(base_path() . "/tools/namecom_api.php");

        $privatekey = Config::get('doolox.fskey_domain');
        $secdata = $_REQUEST['security_data'];
        $sechash = $_REQUEST['security_hash'];

        if (md5($secdata . $privatekey) == $sechash) {
            $domain = Input::get('SubscriptionReferrer');
            $do = Domain::where('url', $domain)->first();

            $api = new NameComApi();
            $api->baseUrl(Config::get('doolox.namecom_url'));
            $api->username(Config::get('doolox.namecom_user'));
            $api->apiToken(Config::get('doolox.namecom_token'));

            $nameservers = array('ns1.name.com', 'ns2.name.com', 'ns3.name.com', 'ns4.name.com');
            $contacts = array(array('type' => array('registrant', 'administrative', 'technical', 'billing'),
                'first_name' => 'Tihomir',
                'last_name' => 'Piha',
                'organization' => 'Click the page Ltd.',
                'address_1' => 'Marice Baric 3',
                'address_2' => '',
                'city' => 'Zagreb',
                'state' => 'Grad Zagreb',
                'zip' => '10000',
                'country' => 'HR',
                'phone' => '+385955388411',
                'fax' => '+385955388411',
                'email' => 'tpiha@naklikaj.com',
            ));

            $response = $api->create_domain($domain, 1, $nameservers, $contacts);
            $code = intval($response->result->code);

            if ($code == 100) {
                $response1 = $api->create_dns_record($domain, '*', 'A', '176.9.133.107', 300);
                $response2 = $api->create_dns_record($domain, 'mail', 'MX', 'mail.doolox.com', 300, 10);

                $do->activated = true;
                $do->save();

                Log::info('FastSpring - domain activated: ' . $domain . ' ' . $response->result->code . ' ' . $response1->result->code . ' ' . $response2->result->code);
            }
            else {
                Log::info('FastSpring - domain activation failed: ' . $domain . ' ' . $response->result->code);
            }
        }
    }

    public function install()
    {
        $conds = array();

        $conds['storage'] = is_writable(base_path() . '/app/storage/');
        $conds['database'] = is_writable(base_path() . '/app/config/database.php');
        $conds['doolox'] = is_writable(base_path() . '/app/config/doolox.php');
        $conds['app'] = is_writable(base_path() . '/app/config/app.php');

        if ($conds['storage'] && $conds['database'] && $conds['doolox'] && $conds['app']) {
            return Redirect::route('doolox.install2');
        }

        return View::make('install')->with('conds', $conds);
    }

    public function install2()
    {
        $app = base_path() . '/app/config/app.php';
        $doolox = base_path() . '/app/config/doolox.php';
        $database = base_path() . '/app/config/database.php';

        $rules = array(
            'dbhost' => 'required_if:database,mysql|required_if:database,pgsql',
            'dbname' => 'required_if:database,mysql|required_if:database,pgsql',
            'dbuser' => 'required_if:database,mysql|required_if:database,pgsql',
            'dbpass' => 'required_if:database,mysql|required_if:database,pgsql',
        );

        $validator = Validator::make(Input::all(), $rules);

        if ($validator->passes()) {
            $url = str_replace('/install2', '', Request::url());
            $key = str_random(32);
            $app_sample = base_path() . '/app/config/app.sample.php';

            self::replace_in_file($app_sample, $app, '__DXURL__', $url);
            self::replace_in_file($app, $app, '__DXKEY__', $key);

            $domain = Config::get('doolox.system_domain');
            $rsa = new Crypt_RSA();
            extract($rsa->createKey());
            $doolox_sample = base_path() . '/app/config/doolox.sample.php';

            self::replace_in_file($doolox_sample, $doolox, '__DXDOMAIN__', $domain);
            self::replace_in_file($doolox, $doolox, '__DXPRIVATE_KEY__', $privatekey);
            self::replace_in_file($doolox, $doolox, '__DXPUBLIC_KEY__', $publickey);

            $database_sample = base_path() . '/app/config/database.sample.php';

            $dbtype = Input::get('database');
            self::replace_in_file($database_sample, $database, '__DXDATABASE__', $dbtype);

            if ($dbtype != 'sqlite') {
                $dbhost = Input::get('dbhost');
                $dbname = Input::get('dbname');
                $dbuser = Input::get('dbuser');
                $dbpass = Input::get('dbpass');

                self::replace_in_file($database, $database, '__DXDBHOST__', $dbhost);
                self::replace_in_file($database, $database, '__DXDBNAME__', $dbname);
                self::replace_in_file($database, $database, '__DXDBUSER__', $dbuser);
                self::replace_in_file($database, $database, '__DXDBPASS__', $dbpass);

                Artisan::call('migrate:install', array());
                Artisan::call('migrate', array());
                Artisan::call('db:seed', array());
            }

            unlink(base_path() . '/app/storage/install');
            Session::flash('success', 'You have successfully installed Doolox. You can now <a href="' . route('user.login') . '">login</a> with these credentials: admin@admin.com / admin');
        }

        return View::make('install2')->withErrors($validator);
    }

    public static function replace_in_file($from, $to, $search, $replace)
    {
        $str = file_get_contents($from);
        $str = str_replace($search, $replace, $str);
        file_put_contents($to, $str);
    }

}