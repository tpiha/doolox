<?php return array(

	// Twitter Bootstrap framework markup
	////////////////////////////////////////////////////////////////////

	// HTML markup and classes used by Bootstrap for icons
	'icon' => array(
		'tag'    => 'i',
		'set'    => null,
		'prefix' => 'icon',
	),

);
