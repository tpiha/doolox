Doolox Todo List
================

### v1.2.1 ###

* Put logging EVERYWHERE
* Self-hosted - remove SaaS stuff + refactoring
* Unit tests
* Put link on Synkee
* Template administration interface

### v1.3.0 ###

* Server setup instructions
* Connect Doolox with mail server
* Tools (Install New WordPress website on FTP server)
* Recovering forgotten password
* Monitoring
* Backup
* Updates
* Depolyment (Synkee integration)
* Ftp servers management (?)
* Website testing environment