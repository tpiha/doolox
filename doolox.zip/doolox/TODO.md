Doolox Todo List
================

### v1.2 ###

* Packaging script
* Self-hosted - remove SaaS stuff + refactoring

### v1.3 ###

* WordPress Template Viewer
* Unit tests
* Tools (Install New WordPress website on FTP server)
* Recovering forgotten password
* Monitoring
* Backup
* Depolyment (Synkee integration)
* Ftp servers management (?)